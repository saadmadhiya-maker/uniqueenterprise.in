# Developer Handover

## Architecture
Multi-page, framework-free semantic HTML + shared JavaScript / CSS. Each page is a separate HTML document for dependable static hosting, indexing, and direct navigation. There is **no React/Vite dependency**; the original React/Vite installation was unavailable during build. `scripts/build.mjs` is a dependency-free Node.js copy-and-verify production builder.

## Main files
- `public/index.html`, `about.html`, `products.html`, `product.html`, `services.html`, `projects.html`, `clients.html`, `contact.html`, `faq.html`, `privacy.html`, `terms.html`, `sitemap.html`, `404.html`
- `public/config.js` business & social settings.
- `public/data.js` catalogue arrays, project references, supported translate languages.
- `public/app.js` shared layout rendering, product search/filter, product detail, quote handoff, language selector and marquee.
- `public/style.css` all styles, animation and breakpoints.
- `public/assets/` approved source assets (including original PDF).

## How to extend
Add a product object to `window.UE_DATA.products` with `slug,name,category,description,image,notes`. A product detail URL automatically works (`/product.html?item=slug`). Add its canonical URL to `sitemap.xml`; consider prerendering dedicated product HTML if you require crawler support without JavaScript. Add new pages as standalone HTML with correct meta title/description/canonical and link in shared menu in `app.js`. For custom domains, update all canonical site links, sitemap.xml and `config.js`.

## Service limitations and legal checks
Google Translate widget is third-party and must be tested on published domain with cookies/scripts enabled. Translation quality and browser availability cannot be guaranteed. Form transfers to WhatsApp with user action; no server-side submission. Source PDF includes irrelevant Indiana company history and an unverified client logo montage; confirm attribution and rights. Legal policy placeholders require professional business review.

## Security
No API keys stored. CSP and cookie-consent should be configured according to production requirements and third-party translations.
