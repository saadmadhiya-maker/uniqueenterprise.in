window.UE_DATA = {
  "products": [
    {
      "slug": "boiler-chimneys",
      "name": "Boiler Chimneys",
      "category": "Chimneys",
      "description": "Industrial steel chimneys for boiler exhaust and flue gas applications.",
      "image": "boiler-chimney.webp",
      "notes": "Catalogue page 7; project-specific design and sizing available upon enquiry."
    },
    {
      "slug": "chimney-stacks",
      "name": "Chimney Stacks",
      "category": "Chimneys",
      "description": "Structural steel stacks for industrial flue-gas discharge.",
      "image": "chimney-stacks.webp",
      "notes": "Catalogue page 8; specifications depend on drawings and operating conditions."
    },
    {
      "slug": "gratings",
      "name": "Industrial Gratings",
      "category": "Fabrication",
      "description": "Mild steel, stainless steel, heavy-duty gratings, stair treads and GRP / FRP varieties shown in catalogue.",
      "image": "gratings.webp",
      "notes": "Catalogue page 4; confirm specification and material before quotation."
    },
    {
      "slug": "handrails",
      "name": "Industrial Handrails",
      "category": "Fabrication",
      "description": "Modular or ball-type and custom fabricated handrails.",
      "image": "handrails.webp",
      "notes": "Catalogue page 4; designed to customer drawings."
    },
    {
      "slug": "cable-management",
      "name": "Cable Management Systems",
      "category": "Systems",
      "description": "Perforated trays, ladder trays, wire mesh trays, support systems, earthing materials and raceways.",
      "image": "cable-management.webp",
      "notes": "Catalogue page 4; availability to be confirmed."
    },
    {
      "slug": "bulk-material-handling",
      "name": "Bulk Material Handling",
      "category": "Systems",
      "description": "Belt conveyors, bucket elevators and related equipment accessories.",
      "image": "material-handling.webp",
      "notes": "Catalogue page 4; discuss project scope for details."
    },
    {
      "slug": "ms-ss-pipeline",
      "name": "MS / SS Pipeline Work",
      "category": "Services",
      "description": "Fabrication support for industrial mild-steel and stainless-steel pipeline requirements.",
      "image": "fabrication.webp",
      "notes": "Core service listed in catalogue."
    },
    {
      "slug": "structural-fabrication",
      "name": "Structural Fabrication",
      "category": "Services",
      "description": "Steel structures and fabricated assemblies for industrial requirements.",
      "image": "gantry.webp",
      "notes": "Core service listed in catalogue."
    },
    {
      "slug": "heavy-industrial-structures",
      "name": "Heavy Industrial Structures",
      "category": "Services",
      "description": "Heavy industrial structure work and fabrication.",
      "image": "power-project.webp",
      "notes": "Core service listed in catalogue."
    },
    {
      "slug": "trial-assembly",
      "name": "Inspection & Trial Assembly",
      "category": "Services",
      "description": "Mock-up and trial assembly for structural fabrication applications.",
      "image": "trial-assembly.webp",
      "notes": "Catalogue page 3."
    }
  ],
  "projects": [
    {
      "name": "Launching Gantry — Reference Gallery",
      "image": "gantry.webp",
      "notes": "Images reproduced from supplied catalogue, p. 5. Attribution/actual scope requires owner confirmation."
    },
    {
      "name": "Power Project — Reference Gallery",
      "image": "power-project.webp",
      "notes": "Industrial structural imagery from supplied catalogue, p. 6. Confirm completed-project ownership before making claims."
    },
    {
      "name": "Industrial Trial Assembly",
      "image": "trial-assembly.webp",
      "notes": "Mock-up launching gantry imagery from supplied catalogue, p. 3."
    },
    {
      "name": "Boiler Chimney Installations",
      "image": "boiler-chimney-2.webp",
      "notes": "Catalogue chimney imagery, p. 7. Confirm installation location and scope."
    },
    {
      "name": "Chimney Stack Structures",
      "image": "chimney-stacks-2.webp",
      "notes": "Catalogue imagery, p. 8. Confirm the portfolio relationship."
    }
  ],
  "languages": [
    [
      "en",
      "English"
    ],
    [
      "hi",
      "Hindi"
    ],
    [
      "gu",
      "Gujarati"
    ],
    [
      "ar",
      "Arabic"
    ],
    [
      "bn",
      "Bengali"
    ],
    [
      "mr",
      "Marathi"
    ],
    [
      "ta",
      "Tamil"
    ],
    [
      "te",
      "Telugu"
    ],
    [
      "ur",
      "Urdu"
    ],
    [
      "fr",
      "French"
    ],
    [
      "de",
      "German"
    ],
    [
      "es",
      "Spanish"
    ],
    [
      "it",
      "Italian"
    ],
    [
      "pt",
      "Portuguese"
    ],
    [
      "ru",
      "Russian"
    ],
    [
      "zh-CN",
      "Chinese (Simplified)"
    ],
    [
      "ja",
      "Japanese"
    ],
    [
      "ko",
      "Korean"
    ],
    [
      "tr",
      "Turkish"
    ],
    [
      "id",
      "Indonesian"
    ]
  ],
  "clientCount": 33
};
