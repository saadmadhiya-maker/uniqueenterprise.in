// Owner-controlled business settings. Keep brand spelling S even though domain has C.
window.UE_CONFIG = {
  businessName: 'Unique Enterprise', domain: 'https://www.uniqueenterprice.in',
  whatsapp: '918735057393', phone: '+918735057393',
  email: 'uniqueenterprise393@gmail.com',
  address: 'Ground Floor, Shed No. 5, Plot No. 4610/B, Shaili Engineering Work, East 14 Road, Ankleshwar, Bharuch, Gujarat - 393002',
  maps: 'https://www.google.com/maps/dir/20.5069481,77.4367817/Glass-Tef+Engineering,+A1,+5241,+near+KHWAZA+CHOCKDI,+Ankleshwar+GIDC,+Ankleshwar,+Gujarat+393002/',
  social: { facebook: 'https://www.facebook.com/share/18Fz2bGbkr/' }
};
