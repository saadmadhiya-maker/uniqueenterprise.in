import fs from 'node:fs'; import path from 'node:path';
const src=path.resolve('public'), out=path.resolve('dist');
fs.rmSync(out,{recursive:true,force:true}); fs.cpSync(src,out,{recursive:true});
const files=[];function walk(d){for(const f of fs.readdirSync(d)){const p=path.join(d,f);if(fs.statSync(p).isDirectory())walk(p);else files.push(p)}}walk(out);
const html=files.filter(f=>f.endsWith('.html'));
for(const p of html){const s=fs.readFileSync(p,'utf8');if(!s.includes('<title>')||!s.includes('name="description"'))throw Error('Missing metadata: '+p);}
console.log(`Production build OK: ${html.length} HTML pages, ${files.length} files`);
