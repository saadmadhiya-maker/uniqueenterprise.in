# Unique Enterprise — Multi-page website

**Canonical brand:** Unique Enterprise (S). **Domain:** uniqueenterprice.in (C).

## Quick start
You need Node.js 18+ for the optional build step; **no npm install is required**.

- To view: serve `public/` using a local static server (`python -m http.server 8000 --directory public`). Open http://localhost:8000.
- To build: `node scripts/build.mjs` creates `dist/` (verified by build script).
- Alternative: `npm run build` uses only Node.js built-ins.
- For Cloudflare Pages: Git repository root; build command `node scripts/build.mjs`; output directory `dist`. Or upload `dist/` as a direct Pages upload.
- For GitHub Pages: upload files from `dist/` to root of your publishing branch. Configure Pages to deploy that branch. For a custom domain include `CNAME`. Your DNS registrar must point the domain to the host according to that host's instructions.

## Editing
- `public/config.js`: company name, contacts, map URL, social links, website URLs.
- `public/data.js`: all product items, services, project examples, FAQs, clients (image assets).
- `public/style.css`: brand colours, layouts, responsive styling and marquee.
- `public/app.js`: shared header, footer, searchable translator, product filtering, product detail page, mobile menu.
- `public/assets/`: original company logo, catalogue-derived industrial images, client-logo image slices, source catalogue PDF.
- Individual HTML documents in `public/`: page-specific main sections and SEO.

## Translation
Google's Website Translate widget loads from `translate.google.com/translate_a/element.js`. The header's searchable language selector requests Google Translate to translate page content, not merely display another language label. Cookies / network access to Google are required. Google controls support and machine-translation quality; it may be blocked, unavailable, or not translate dynamic content fully. Confirm with the business before adding paid translation, consent handling or private key services. No secret keys are in this repository.

## Contact / forms
WhatsApp opens a real wa.me chat with a prefilled message. Telephone and email links use `tel:` and `mailto:`. The quote form builds a WhatsApp message; it does not submit to a server or store data. No backend required.

## SEO
Each HTML page has unique title / description / canonical / Open Graph metadata; sitemap.xml and robots.txt included. Update meta text, URL and sitemap on adding pages. Google Search Console: verify domain ownership with DNS, then submit `https://www.uniqueenterprice.in/sitemap.xml`. Analytics not installed; configure consent and measurement ID if required. Business address and contacts were supplied by owner and have not been externally verified.

## IMPORTANT CONTENT REVIEW
The provided PDF page 2 incorrectly describes **Indiana**, an unrelated company. This content was excluded. Catalogue 'VSL INDIA Launching Gantry', power-plant and broad client logos are presented as supplied portfolio/reference imagery only, not independently verified Unique Enterprise completed contracts or direct clients. Confirm rights/relationships before public publication. Never invent prices, certifications, years in business, installed capacity or project metrics. Privacy and terms content has **[REVIEW]** sections requiring legal approval.

## Deployment / troubleshooting
- Blank page or 404: ensure `index.html` and page HTML files reside at the host root, not nested inside an extra folder.
- 404 on internal navigation: deploy all separate `.html` pages, not only index.html.
- Missing images: preserve `assets/` folder and exact case-sensitive filenames.
- External Google translation blocked: permit third-party scripts or switch to an approved translation provider.
- DNS and HTTPS: set your Cloudflare Pages custom domain via Pages > Custom domains and follow provided DNS records; verify certificate and both www and apex redirect settings.
- Social, map or WhatsApp contact: update central `config.js` only.
- `npm install` is unnecessary and was not used.
